package cs6235.a1.submission;

import java.util.Map;

import cs6235.a1.AnalysisBase;

public class PointsToAnalysis extends AnalysisBase {

	@Override
	public String getResultString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void internalTransform(String phaseName, Map<String, String> options) {
		// TODO Auto-generated method stub

	}

}
